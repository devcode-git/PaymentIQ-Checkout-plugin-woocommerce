<?php

/**
 * @package PaymentIQ Checkout Plugin for Woocommerce
 */

 class Piq_Co_Activate {
   public static function activate () {
  
   }
 }