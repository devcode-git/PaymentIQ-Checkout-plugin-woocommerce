<?php

/**
 * @package PaymentIQ Checkout Plugin for Woocommerce
 */

 class Piq_Co_Deactivate {
   public static function deactivate () {}
 }