<?php
/**
 * PaymentIQ Checkout uninstall
 *
 * @package PaymentIQCheckout
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

// Clear database of PaymentIQ Checkout data goes here